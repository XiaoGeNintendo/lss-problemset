import os
for i in range(20):
    os.system("a 100000 %d >test%d.in"%(i+1,i))