#include <bits/stdc++.h>
using namespace std;
string toString(int num){
	bool negative=false;
	if(num<0) negative=true;
	num=abs(num);
	string s;
	while(num!=0){
		s+=num%10+'0';
		num/=10;
    }
    reverse(s.begin(),s.end());
    if(negative) s='-'+s;
    return s;
}
	

int main(){
	srand(time(0));
	for(int i=0;i<20;i++){
		freopen(("test"+toString(i)+".in").c_str(),"w",stdout);
		for(int j=0;j<100000;j++){
			cout<<rand()%12<<" "<<rand()%60<<" "<<rand()+1<<endl;
		}
	} 
} 
