#include <bits/stdc++.h>
using namespace std;
set<int> s={1, 2, 3, 5, 6, 9, 10, 13, 17 };
int main(){
	int x;
	while(cin>>x){
		if(s.count(x)){
			cout<<"NO"<<endl;
		}else{
			cout<<"YES"<<endl;
		}
	} 
}
