#include <iostream>
using namespace std;
int main(){
	for(int i=0;i<12;i++){
		for(int j=0;j<=59;j++){
			cout<<i<<" "<<j<<" 1"<<endl;
		}
	}
} 
