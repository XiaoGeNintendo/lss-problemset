import os
rng=int(input("Range:"))
ex=input("Ex:")
for i in range(0,rng):
    
    os.system('sol.exe <'+ex+str(i)+'.in >'+ex+str(i)+'.out')
    print("Success for ",i)
