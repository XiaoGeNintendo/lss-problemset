import os
x=os.listdir('main')
y=-1
for i in x:
    if '.in' in i:
        y+=1
        print('main/'+i,'main/test'+str(y)+'.in')
        os.rename('main/'+i,'main/test'+str(y)+'.in')
    else:
        print('main/'+i,'main/test'+str(y)+'.out')
        os.rename('main/'+i,'main/test'+str(y)+'.out')
    