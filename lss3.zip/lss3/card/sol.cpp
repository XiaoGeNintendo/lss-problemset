#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <queue>
#include <map>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <deque>
#include <bits/stdc++.h>
//#include "testlib.h"
using namespace std;
#define ll long long
#define pii pair<int,int>
#define qi ios::sync_with_stdio(0)

bool debug=true;

/*    *************************************
	  * Written in New Computer           *
	  * The following code belongs to     *
	  * XiaoGeNintendo of HellHoleStudios *
	  *************************************
*/
template<typename T1,typename T2>ostream& operator<<(ostream& os,pair<T1,T2> ptt){
	os<<ptt.first<<","<<ptt.second;
	return os;
}
template<typename T>ostream& operator<<(ostream& os,vector<T> vt){
	os<<"{";
	for(int i=0;i<vt.size();i++){
		os<<vt[i]<<" ";
	}
	os<<"}";
	return os;
}

int n,m;
int a[200005];
int b[200005];
int c[200005];

const ll mod=1e9+7;

int main(int argc,char* argv[]){
	qi;
	cin>>n>>m;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	for(int i=0;i<m;i++){
		cin>>b[i];
	}
	
	sort(a,a+n);
	sort(b,b+m);
	
	int x=n-1;
	for(int i=m-1;i>=0;i--){
//		cout<<b[i]<<" "<<a[x]<<endl;
		while(x>=n-m && a[x]>=b[i]){
			x--;
//			cout<<"-- "<<b[i]<<" "<<a[x]<<endl;
		}
		c[i]=n-x-1;
//		cout<<c[i]<<" ";
	}
	
	ll ans=1;
	for(int i=m-1;i>=0;i--){
		ans*=(c[i]-(m-1-i));
		ans%=mod;
	}
	cout<<ans<<endl;
	return 0;
}


