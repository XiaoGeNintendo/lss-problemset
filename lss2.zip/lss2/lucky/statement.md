# Statement
Ookami is a werewolf girl. One day, she saw a tattoo from her human friend ZJS. The tattoo contains two numbers: 4 and 7. 

"Why you keep this two numbers?" Ookami asked

"Well. I consider it to be lucky!" ZJS replied.

ZJS thinks all positive numbers that contain only 4 and 7 to be lucky. For example, "4" "7" "44" "77" "774" are all lucky numbers, while "1" "7788" "471" are not.

"Then why these numbers are lucky?" Ookami asked again.

"Because for each number greater than 7, we can represent it as the sum of lucky numbers!" ZJS replied.

Is it really so? Please write a program that: 

- Takes numbers from stdin
- Print "YES" if it can be represented by sum of lucky numbers, "NO" otherwise

# Input
In each testcase, there's one line containing 1 integer: N

Proceed to the EOF
# Output
YES or NO. One in a line.
# Example
```
[Input]
4
7
11
13
121
[Output]
YES
YES
YES
NO
YES
[Explain]
4=4
7=7
11=4+7
we cannot get 13.
121=44+77
```
# Subtask
The number of testcases does not exceed 1e6. Thus, it's preferred to use scanf.

For test #1-#9, $1\leq N\leq 10^6$

For test #10, $1\leq N\leq 10^9$
