#include <iostream>
using namespace std;
int main(){
	for(int i=1;i<=1000000;i++){
		cout<<i<<endl;
	}
}
