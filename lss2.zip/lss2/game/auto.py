import os
x=os.listdir("big")
for i in range(23,64):
    os.rename("big/test"+str(i)+".in","big/test"+str(i-23)+".in")
    os.rename("big/test"+str(i)+".out","big/test"+str(i-23)+".out")