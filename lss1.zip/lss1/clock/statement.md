# Statement
Ookami is a werewolf girl. She studies in NFLS Class 8 Junior 3.

Having had too little for breakfast, she is hungry after 3 lessons in the morning. She wanted to have lunch ASAP. She remembered that in the ancient time, the werewolves would get together to eat when **the hour hand coincides the minute hand** on a simple round clock.

Now it is A:B in the morning, Ookami wants to know after how many minutes she would have her k-th meal if she lived in ancient time?
# Input
In each testcase, there's one line contains 3 integers: A,B,K

Proceed to the EOF
# Output
The answer. Your answer will be considered correct if it's relative error doesn't exceed 1e-6.
# Example
```
In:
0 0 1
11 59 1
0 0 2
Out:
0.000000
1.000000
65.454545
```
# Subtask
There are 11 testcases. 

Testcase 1: $K=1$

Testcase 2-11: $1\leq K\leq 32768$

For all testcases, $0\leq A\leq 11,0\leq B\leq 59$

There will be no more than 1e5 cases in one testcase.