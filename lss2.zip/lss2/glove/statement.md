# Statement
**This problem's maximum score is 50. This is an easy version.**

Ninetail is a fox girl. She has some gloves in different colors. She has two drawers. So she put all the left-hand gloves into drawer #1 and all the right-hand gloves into drawer #2.

One day, she decided to take out A gloves randomly from drawer #1 and B gloves randomly from drawer #2. Question: Is it certain that ninetail will get a pair of gloves of the same color?

# Input
The first line contains integer N. The number of colors.

Then the second line contains A1...AN. The number of gloves of each colors in drawer 1

Then the third line contains B1...BN. The number of gloves of each colors in drawer 2

The last line contains A and B
# Output
YES or NO. One in a line.
# Example
```
[Input]
4
1 2 3 4
4 3 2 1
5 6
[Output]
NO
[Explain]
If unfortunately, we get color {4,4,4,4,3} from drawer 1 and {1,1,1,1,2,2} from drawer 2 we won't have a pair of gloves of the same kind.

[Input]
4
1 2 3 4
4 3 2 1
7 8
[Output]
YES
```

# Note
If Ninetail tell you she wants to get gloves more than the sum of gloves in the drawer(ie. $A\gt \sum_{i=1}^NA_i$ or for B). Just treat she is drunk and print "YES".
# Subtask
$1\leq N\leq 20,0\leq Ai,Bi\leq 32767,0\leq A\leq 32767,0\leq B\leq 32767$

**You need to pass all testcases to get score**