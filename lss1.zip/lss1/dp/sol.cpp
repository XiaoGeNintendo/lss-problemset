#include <bits/stdc++.h>
using namespace std;
#define ll long long
const ll mod=1e9+7;
const int mx=2000000;

ll f[mx+5];
ll inv[mx+5];

inline ll C(int a,int b){
	return f[a]*inv[b]%mod*inv[a-b]%mod;
}

inline ll qp(ll a,ll b){
	if(b==0){
		return 1;
	}
	ll ans=qp(a,b/2);
	if(b%2){
		return ans*ans%mod*a%mod;
	}else{
		return ans*ans%mod;
	}
}

int main(){
	f[0]=1;
	inv[0]=1;
	for(int i=1;i<=mx;i++){
		f[i]=f[i-1]*i%mod;
		inv[i]=qp(f[i],mod-2);
	}
	
	ll a,b,c,d;
	while(cin>>a>>b>>c>>d){
		c--;d--; 
		cout<<C(c+d,c)*qp(a,c)%mod*qp(b,d)%mod<<endl;
	}
}
