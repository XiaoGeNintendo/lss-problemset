import os
x=[1,2,3,5,10,20,40,100,200,500,1e3,2e3,5e3,1e4,2e4,5e4,1e5,1e5,2e5,2e5]
y=[3,3,3,3,3 ,3 ,3 ,3  ,3  ,3  ,3  ,3  ,3  ,3  ,3  ,3  ,3  ,1  ,3  ,1]
for i in range(20):
    os.system("gen %d %d >test%d.in"%(x[i],y[i],i))