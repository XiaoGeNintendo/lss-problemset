#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <queue>
#include <map>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <deque>
#include <bits/stdc++.h>
//#include "testlib.h"
using namespace std;
#define ll long long
#define pii pair<int,int>
#define qi ios::sync_with_stdio(0)

bool debug=true;

/*    *************************************
	  * Written in New Computer           *
	  * The following code belongs to     *
	  * XiaoGeNintendo of HellHoleStudios *
	  *************************************
*/
template<typename T1,typename T2>ostream& operator<<(ostream& os,pair<T1,T2> ptt){
	os<<ptt.first<<","<<ptt.second;
	return os;
}
template<typename T>ostream& operator<<(ostream& os,vector<T> vt){
	os<<"{";
	for(int i=0;i<vt.size();i++){
		os<<vt[i]<<" ";
	}
	os<<"}";
	return os;
}

string s,t;
int main(int argc,char* argv[]){
	qi;
	cin>>s>>t;
	
	//minus 1 from t
	for(int i=t.size()-1;i>=0;i--){
		if(t[i]=='0'){
			t[i]='9';
		}else{
			t[i]--;
			break;
		}
	}
	
//	cout<<t<<endl;
	
	vector<char> v;
	set<char> st;
	for(int i=0;i<s.size();i++){
		if(!st.count(s[i])){
			v.push_back(s[i]);
			st.insert(s[i]);
		}
	}

//	cout<<v<<endl;
	
	int afterLen=t.size()-(t[0]=='0');
	if(afterLen>v.size()){
		cout<<"ZJS!!";
		return 0;
	}
	
	map<char,int> mp;
	int x=t.size()-1;
	for(int i=v.size()-1;i>=0;i--){
		mp[v[i]]=(x<0?0:t[x]-'0');
		if(i==0){
			mp[v[i]]++;
		}
		
		if(mp[v[i]]<0 || mp[v[i]]>=10){
			cout<<"ZJS!!"<<endl;
			return 0;
		}
		x--;
	}
	
	for(int i=0;i<s.size();i++){
		cout<<mp[s[i]];
	}
	return 0;
}


