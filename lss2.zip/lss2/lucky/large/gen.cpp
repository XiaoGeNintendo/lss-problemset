#include <bits/stdc++.h>
using namespace std;
mt19937_64 gen (std::random_device{}());
inline int rx(int x){
	return gen()%x+1;
}
int main(){
	for(int i=1;i<=1000000;i++){
		cout<<rx(1000000000)<<endl;
	}
}
