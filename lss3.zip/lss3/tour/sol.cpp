#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <queue>
#include <map>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <deque>
#include <bits/stdc++.h>
//#include "testlib.h"
using namespace std;
#define ll long long
#define pii pair<int,int>
#define qi ios::sync_with_stdio(0)

bool debug=true;

/*    *************************************
	  * Written in New Computer           *
	  * The following code belongs to     *
	  * XiaoGeNintendo of HellHoleStudios *
	  *************************************
*/
template<typename T1,typename T2>ostream& operator<<(ostream& os,pair<T1,T2> ptt){
	os<<ptt.first<<","<<ptt.second;
	return os;
}
template<typename T>ostream& operator<<(ostream& os,vector<T> vt){
	os<<"{";
	for(int i=0;i<vt.size();i++){
		os<<vt[i]<<" ";
	}
	os<<"}";
	return os;
}

int n;
vector<pii> nei[100005];

ll dis[100005];

void dfs(int pos,int par,ll dist){
	dis[pos]=dist;
	for(pii x:nei[pos]){
		if(x.first==par){
			continue;
		}
		dfs(x.first,pos,dist+x.second);
	}
}

void runDis(int s){
	memset(dis,0,sizeof(dis));
	
	dfs(s,-1,0);
}

int main(int argc,char* argv[]){
	qi;
	cin>>n;
	ll ans=0;
	for(int i=0;i<n-1;i++){
		int a,b,c;
		cin>>a>>b>>c;
		a--;b--;
		ans+=2ll*c;
		nei[a].push_back(make_pair(b,c));
		nei[b].push_back(make_pair(a,c));
	}
	
	runDis(0);
	
	ll mx=0;
	for(int i=0;i<n;i++){
		if(dis[i]>dis[mx]){
			mx=i;
		}
	}
	
	runDis(mx);
	mx=0;
	for(int i=0;i<n;i++){
		mx=max(mx,dis[i]);
	}
	
	cout<<ans-mx<<endl;
	return 0;
}


