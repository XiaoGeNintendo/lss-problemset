#include <bits/stdc++.h>
using namespace std;
int main(){
	int a,b,c;
	while(cin>>a>>b>>c){
		double minute=6*b;
		double hour=30*a+0.5*b;
		double delta=hour-minute+360;
		if(delta>=360){
			delta-=360;
		}
		
		printf("%.10f\n",delta/(6-0.5)+720/11.0f*(c-1));
	}
}
