#include <bits/stdc++.h>
using namespace std;
string toString(int num){
	bool negative=false;
	if(num<0) negative=true;
	num=abs(num);
	string s;
	while(num!=0){
		s+=num%10+'0';
		num/=10;
    }
    reverse(s.begin(),s.end());
    if(negative) s='-'+s;
    return s;
}

std::mt19937_64 gen (std::random_device{}());
inline int rx(int x){
	return gen()%x+1;
}

int main(){


    
	for(int tc=0;tc<10;tc++){
		freopen(("test"+toString(tc)+".in").c_str(),"w",stdout);
		for(int i=0;i<100000;i++){
			cout<<rx(100000)<<" "<<rx(100000)<<" "<<rx(100000)<<" "<<rx(100000)<<endl;
		}		
	}
}
