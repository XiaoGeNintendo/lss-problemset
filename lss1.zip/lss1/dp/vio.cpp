#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <queue>
#include <map>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <deque>
#include <bits/stdc++.h>
//#include "testlib.h"
using namespace std;
#define ll long long
#define pii pair<int,int>
#define qi ios::sync_with_stdio(0)

bool debug=true;

/*    *************************************
	  * Written in New Computer           *
	  * The following code belongs to     *
	  * XiaoGeNintendo of HellHoleStudios *
	  *************************************
*/
template<typename T1,typename T2>ostream& operator<<(ostream& os,pair<T1,T2> ptt){
	os<<ptt.first<<","<<ptt.second;
	return os;
}
template<typename T>ostream& operator<<(ostream& os,vector<T> vt){
	os<<"{";
	for(int i=0;i<vt.size();i++){
		os<<vt[i]<<" ";
	}
	os<<"}";
	return os;
}

ll f[1005][1005];
ll a,b,c,d;
const ll mod=1e9+7;

int main(int argc,char* argv[]){
	
	while(cin>>a>>b>>c>>d){
		f[1][1]=1;
		for(int i=1;i<=c;i++){
			for(int j=1;j<=d;j++){
				if(i==1 && j==1){
					continue;
				}
				f[i][j]=(a*f[i-1][j]%mod+b*f[i][j-1]%mod)%mod;
			}
		}
		cout<<f[c][d]<<endl;
	}
	return 0;
}


