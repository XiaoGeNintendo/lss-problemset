#include "testlib.h"
#include <algorithm>
#define MAXN 20

struct glove
{
	int l,r;
	bool operator < (const glove &a){
		return l!=a.l?l<a.l:r>a.r;
	}
};

glove sta[1<<20|1],p[1<<20|1],oksol[1<<20|1];
int a[2][MAXN],top,n,x,l,r,L,R,pt;
int ansa=~(1<<31),ansl,ansr,usrl,usrr;

inline void check(int x,int y)
{
	if (ansa==x+y) oksol[++pt]=(glove){x+l,y+r};
	if (ansa>x+y){ansa=x+y;oksol[pt=1]=(glove){x+l,y+r};}
	return ;
}

int main(int argc, char *argv[])
{
	registerTestlibCmd(argc, argv);
	x=inf.readInt();ansl=ans.readInt();ansr=ans.readInt();

	for (int i=0;i<=1;i++)
		for (int j=0;j<x;j++)
			a[i][j]=inf.readInt();

	for (int i=0;i<x;i++) L+=a[0][i],R+=a[1][i];
	usrl=ouf.readInt(1,L);usrr=ouf.readInt(1,ansl+ansr-usrl);
	if (usrl==ansl&&usrr==ansr)
		quitf(_ok,"^ ^Your answer is right!");

	for (int i=0;i<x;i++)
	{
		if (!a[0][i]||!a[1][i]){l+=a[0][i];r+=a[1][i];}
		else{a[0][n]=a[0][i];a[1][n++]=a[1][i];}
	}
	for (int i=0;i<(1<<n);i++)
		for (int j=0;j<n;j++)
		{
			if (i&(1<<j)) p[i].r+=a[1][j];
			else p[i].l+=a[0][j];
		}
	check(p[0].l,1);check(1,p[(1<<n)-1].r);
	std::sort(p,p+(1<<n));
	for (int i=0;i<(1<<n);i++)
	{
		while (top&&sta[top].r<p[i].r) top--;
		sta[++top]=p[i];
	}
	for (int i=2;i<=top;i++) check(sta[i-1].l+1,sta[i].r+1);
	for (int i=1;i<=pt;i++)
		if (oksol[i].l==usrl&&oksol[i].r==usrr)
			quitf(_ok,"^ ^Your answer is right");
	quitf(_wa,"Your answer is wrong.");
	return 0;
}