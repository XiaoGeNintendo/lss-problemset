#include <bits/stdc++.h>
using namespace std;
string toString(int num){
	bool negative=false;
	if(num<0) negative=true;
	num=abs(num);
	string s;
	while(num!=0){
		s+=num%10+'0';
		num/=10;
    }
    reverse(s.begin(),s.end());
    if(negative) s='-'+s;
    return s;
}
	

int main(){
	for(int tc=0;tc<10;tc++){
		freopen(("test"+toString(tc)+".in").c_str(),"w",stdout);
		int n=rand()%100+1;
		int m=rand()%100+1;
		int k=rand()%min(m,(n+1)/2)+1;
		cout<<n<<" "<<m<<" "<<k<<endl;
		
		for(int i=0;i<n;i++){
			for(int j=0;j<m;j++){
				cout<<rand()<<" ";		
			}
			cout<<endl;
		}
		
//		for(int i=0;i<1000;i++){
//			cout<<rand()%1000+1<<" "<<rand()%1000+1<<" "<<rand()%1000+1<<" "<<rand()%1000+1<<endl;
//		}		
	}
}
