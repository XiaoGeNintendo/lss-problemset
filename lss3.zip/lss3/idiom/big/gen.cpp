#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <queue>
#include <map>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <deque>
#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define pii pair<int,int>
#define qi ios::sync_with_stdio(0)

bool debug=true;

/*    *************************************
	  * Written in New Computer           *
	  * The following code belongs to     *
	  * XiaoGeNintendo of HellHoleStudios *
	  *************************************
*/
template<typename T1,typename T2>ostream& operator<<(ostream& os,pair<T1,T2> ptt){
	os<<ptt.first<<","<<ptt.second;
	return os;
}
template<typename T>ostream& operator<<(ostream& os,vector<T> vt){
	os<<"{";
	for(int i=0;i<vt.size();i++){
		os<<vt[i]<<" ";
	}
	os<<"}";
	return os;
}

string toString(int num){
	bool negative=false;
	if(num<0) negative=true;
	num=abs(num);
	string s;
	while(num!=0){
		s+=num%10+'0';
		num/=10;
    }
    reverse(s.begin(),s.end());
    if(negative) s='-'+s;
    return s;
}

mt19937_64 gen (std::random_device{}());
inline int rx(int x){
	return gen()%x+1;
}

void fo(string s){
	freopen(s.c_str(),"w",stdout);
} 

int main(int argc,char* argv[]){
	srand(time(0));
	int t=20;
	while(t--){
		fo("test"+toString(t)+".in");
		int n=rx(100000);
		for(int i=0;i<n;i++){
			cout<<char(rand()%26+'A');
		}
		cout<<" ";
		cout<<rx(999999)<<rx(999999)<<rx(999999)<<endl;
	}

	return 0;
}


