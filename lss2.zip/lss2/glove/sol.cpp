#include <bits/stdc++.h>
using namespace std;
int n;
int a[25],b[25],l,r;
int main(){
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	for(int i=0;i<n;i++){
		cin>>b[i];
	}
	cin>>l>>r;
	for(int i=0;i<(1<<n);i++){
		int x=0,y=0;
		for(int j=0;j<n;j++){
			if(i&(1<<j)){
				x+=a[j];
			}else{
				y+=b[j];
			}
		}
		
		if(!(l>x || r>y)){
			cout<<"NO"<<endl;
			return 0;
		}
	}
	cout<<"YES"<<endl;
	
} 
