#include <iostream>
#include <algorithm>
#include <vector>
#include <set>
#include <queue>
#include <map>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <deque>
#include <bits/stdc++.h>
#include "testlib.h"
using namespace std;
#define ll long long
#define pii pair<int,int>
#define qi ios::sync_with_stdio(0)

bool debug=true;

/*    *************************************
	  * Written in New Computer           *
	  * The following code belongs to     *
	  * XiaoGeNintendo of HellHoleStudios *
	  *************************************
*/
template<typename T1,typename T2>ostream& operator<<(ostream& os,pair<T1,T2> ptt){
	os<<ptt.first<<","<<ptt.second;
	return os;
}
template<typename T>ostream& operator<<(ostream& os,vector<T> vt){
	os<<"{";
	for(int i=0;i<vt.size();i++){
		os<<vt[i]<<" ";
	}
	os<<"}";
	return os;
}


int main(int argc,char* argv[]){
	registerGen(argc,argv,1);
	
	int m=atoi(argv[1]);
	int w=atoi(argv[2]);
	int n=rnd.wnext(m,min(2*m,200000),w);
	cout<<n<<" "<<m<<endl;
	for(int i=0;i<n;i++){
		cout<<rnd.wnext(1,1000000000,w)<<" ";
	}
	cout<<endl;
	for(int i=0;i<m;i++){
		cout<<rnd.next(1,1000000000)<<" ";
	}
	return 0;
}


