#include <bits/stdc++.h>
using namespace std;
int main(){
	srand(time(0));
	int n=20;
	cout<<n<<endl;
	for(int i=0;i<n;i++){
		cout<<rand()%20<<" ";
	}
	cout<<endl;
	for(int i=0;i<n;i++){
		cout<<rand()%20<<" ";
	}
	cout<<endl;
	cout<<400-rand()%10<<" "<<400-rand()%10<<endl;
}
